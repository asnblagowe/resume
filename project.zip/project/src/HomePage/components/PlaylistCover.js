function PlaylistCover({ url }) {
  return <img src={url} className="rounded shadow-lg" alt="" />;
}

export default PlaylistCover;
