import TheFooterList from './TheFooterList';

function TheFooter() {
  return (
    <footer className="mt-auto mb-8 ml-6">
      <TheFooterList />
    </footer>
  );
}

export default TheFooter;
