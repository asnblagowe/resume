import React from "react";
import HomePage from "./HomePage/HomePage";

const App = () => {
  return <HomePage />;
};

export default App;
